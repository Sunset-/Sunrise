
module.exports = {
    host : '192.168.0.148',
    username : 'root',
    password : '',
    database : 'db_referral',
    dialect : 'mysql',
    pool : {
        min : 1,
        max : 20,
        idle : 10000
    }
}