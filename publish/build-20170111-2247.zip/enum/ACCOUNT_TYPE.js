module.exports = {
    HOSPITAL : 1
}