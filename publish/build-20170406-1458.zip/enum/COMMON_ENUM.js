module.exports = {
    TRUE_FALSE: {
        TRUE: 1,//是
        FALSE: 0//否
    }
}