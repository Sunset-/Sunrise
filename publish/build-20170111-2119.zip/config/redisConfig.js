
module.exports = {
    host : '192.168.0.148',
    port : 6370,
    auth : 'peaimage'
};