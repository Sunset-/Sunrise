module.exports = {
    RESET_PASSWORD : '123456'
}