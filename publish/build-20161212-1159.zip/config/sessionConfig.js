module.exports = {
    key : 'SUNRISESESSIONID',
    maxAge : 60*60*1000,
    signed : false,
    auth : false,
    unAuthPaths : ['/sign/login']
}